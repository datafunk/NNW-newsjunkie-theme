---
date: 2021-09-22 00:00
creator: @datafunk
tags: Default Theme, Dark Only
link: https://github.com/datafunk/NNW-newsjunkie-theme
---

I found the available dark themes to be too high a contrast to my eyes when reading at night, so when 6.1 came along I jumped to make something that works for me.
Even better if it also works for you too, so I thought I share it. 